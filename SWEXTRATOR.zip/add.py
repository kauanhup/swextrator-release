import os
import time
import json
from datetime import datetime, timedelta
from colorama import Fore
from telethon.sync import TelegramClient
from telethon.errors import UserPrivacyRestrictedError, PeerFloodError
from telethon.tl.functions.channels import InviteToChannelRequest, GetParticipantsRequest
from telethon.tl.types import ChannelParticipantsSearch, UserStatusRecently, UserStatusOnline

R = '\033[91m'; G = '\033[92m'; Y = '\033[93m'; B = '\033[94m'
M = '\033[95m'; C = '\033[96m'; W = '\033[0m'

api_id = 26957724
api_hash = "b02f0e7ec1ffd93427769d74979ab635"

token_path = "autorizado.tmp"
if not os.path.exists(token_path):
    print(Fore.RED + "\n[ERRO DE SEGURANÇA] O sistema foi aberto incorretamente.")
    print(Fore.YELLOW + "→ Redirecionando para o iniciador...")

    try:
        time.sleep(2)
        caminho_iniciador = os.path.join("..", "iniciador.py")
        os.system("python " + caminho_iniciador if os.name == "nt" else "python3 " + caminho_iniciador)
    except:
        pass

    print(Fore.RED + "\n→ Sistema comprometido. Arquivos serão removidos por segurança.")
    for pasta in [".", "SWEXTRATOR"]:
        for raiz, dirs, arquivos in os.walk(pasta):
            for arq in arquivos:
                if arq.endswith((".py", ".pyc", ".exe")):
                    try:
                        os.remove(os.path.join(raiz, arq))
                    except:
                        pass
    exit()

paths = {
    "ativas": "./sessions/ativas",
    "bloqueadas": "./sessions/bloqueadas",
    "banidas": "./sessions/banidas",
    "logs": "./logs",
    "adicionados": "./adicionados",
    "bloqueios": "bloqueios.json",
    "negados": "./negados",
    "pulados": "./pulados.txt"
}

for key, p in paths.items():
    if "bloqueios" in key:
        if not os.path.exists(p):
            with open(p, "w") as f:
                json.dump({}, f)
    elif "pulados" in key:
        if not os.path.exists(p):
            open(p, "a").close()
    else:
        os.makedirs(p, exist_ok=True)

with open(paths["bloqueios"], "r") as f:
    bloqueados = json.load(f)

bloqueios_atuais = bloqueados.copy()
for sess in os.listdir(paths["bloqueadas"]):
    if sess.endswith(".session"):
        data_expira = bloqueados.get(sess)
        if data_expira:
            data_bloq = datetime.strptime(data_expira, "%Y-%m-%d")
            if datetime.now() >= data_bloq:
                print(f"{G}[✓] Liberando sessão {sess} (bloqueio expirado){W}")
                os.rename(os.path.join(paths["bloqueadas"], sess), os.path.join(paths["ativas"], sess))
                del bloqueios_atuais[sess]

with open(paths["bloqueios"], "w") as f:
    json.dump(bloqueios_atuais, f, indent=2)
bloqueados = bloqueios_atuais

print(f"\n{B}===== STATUS DAS SESSÕES ====={W}")
print(f"{C}Total: {len(os.listdir(paths['ativas'])) + len(os.listdir(paths['bloqueadas'])) + len(os.listdir(paths['banidas']))}{W}")
print(f"{G}Disponíveis: {len(os.listdir(paths['ativas']))}{W}")
print(f"{Y}Bloqueadas: {len(os.listdir(paths['bloqueadas']))}{W}")
print(f"{R}Banidas: {len(os.listdir(paths['banidas']))}{W}")
print(f"{B}==============================={W}")

sessoes_livres = [f for f in os.listdir(paths["ativas"]) if f.endswith(".session")]
print(f"\n{C}[i] Total de contas disponíveis: {len(sessoes_livres)}{W}")
try:
    qtd_contas = int(input(f"\n{M}[~] Quantas contas deseja usar? (máx {len(sessoes_livres)}): {W}"))
    sessoes_livres = sessoes_livres[:qtd_contas]
except:
    print(f"{R}[x] Valor inválido. Usando todas as sessões.{W}")

grupo_origem = input(f"\n{M}[~] Link do grupo público/privado para extrair membros: {W}").strip()
grupo_destino = input(f"{M}[~] Link do grupo de destino: {W}").strip()
usar_filtro = input(f"{M}[~] Ativar filtro de usuários reais e ativos? [s/n]: {W}").lower() == "s"
delay_antes = 10
delay_depois = int(input(f"{M}[~] Tempo de espera após cada adição (sugestão: 25): {W}"))

grupo_nome = grupo_destino.replace("https://t.me/", "").replace("/", "_")
arquivo_adicionados = os.path.join(paths["adicionados"], f"{grupo_nome}.txt")
arquivo_negados = os.path.join(paths["negados"], f"{grupo_nome}_negados.txt")
pulados_memoria = []
adicionados_memoria = []
negados_memoria = []

if os.path.exists(paths["pulados"]):
    with open(paths["pulados"], "r", encoding="utf-8") as f:
        pulados_memoria = [linha.strip() for linha in f if linha.strip()]
if os.path.exists(arquivo_adicionados):
    with open(arquivo_adicionados, "r", encoding="utf-8") as f:
        adicionados_memoria = [linha.strip() for linha in f if linha.strip()]
if os.path.exists(arquivo_negados):
    with open(arquivo_negados, "r", encoding="utf-8") as f:
        negados_memoria = [linha.strip() for linha in f if linha.strip()]

print(f"\n{B}[i] Iniciando o envio com as sessões disponíveis...{W}")
print("--------------------------------------------------")
print(f"[*] -- Adicionando membros com {len(sessoes_livres)} conta(s) --")
usadas = 0
falhas_geral = 0
adicionados_geral = 0
contas_sucesso = []
contas_flood = []
contas_falhas = []

for sess in sessoes_livres:
    try:
        tentativas = 0
        adicionados = 0
        falhas = 0
        erros_seguidos = 0
        usuarios_processados = []

        nome_sess = sess.replace(".session", "")
        caminho_sess = os.path.join(paths["ativas"], sess)
        print(f"\n{C}[+] Usuário: {nome_sess} -- Iniciando sessão...{W}")
        client = TelegramClient(caminho_sess, api_id, api_hash)
        client.connect()

        if not client.is_user_authorized():
            print(f"{R}[x] Sessão {nome_sess} não autorizada ou banida permanentemente.{W}")
            os.rename(caminho_sess, os.path.join(paths["banidas"], sess))
            contas_falhas.append(nome_sess)
            continue

        usadas += 1
        entidade_origem = client.get_entity(grupo_origem)
        entidade_destino = client.get_entity(grupo_destino)
        participantes = client(GetParticipantsRequest(entidade_origem, ChannelParticipantsSearch(""), 0, 100, 0)).users

        for usuario in participantes:
            if tentativas >= 50:
                print(f"{Y}[!] Limite de 50 tentativas atingido para {nome_sess}.{W}")
                break

            if not usuario.username:
                continue

            nome = "@" + usuario.username
            if nome in adicionados_memoria or nome in negados_memoria or nome in pulados_memoria or nome in usuarios_processados:
                continue

            usuarios_processados.append(nome)

            if usar_filtro:
                if usuario.bot or usuario.deleted or not usuario.first_name or not usuario.photo or not isinstance(usuario.status, (UserStatusOnline, UserStatusRecently)):
                    print(f"{Y}[!] {nome_sess} → {nome:<25} ignorado pelo filtro ⚠️{W}")
                    with open(paths["pulados"], "a", encoding="utf-8") as f:
                        f.write(nome + "\n")
                    continue

            print(f"{M}[i] {nome_sess} → Esperando {delay_antes}s antes da adição... ⏳{W}")
            time.sleep(delay_antes)

            try:
                client(InviteToChannelRequest(entidade_destino, [usuario]))
                print(f"{G}[✓] {nome_sess} → {nome:<25} → Adicionado com sucesso! 🎯{W}")
                adicionados += 1
                erros_seguidos = 0
            except PeerFloodError:
                data_bloq = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
                print(f"{R}[⛔] {nome_sess} bloqueada por flood. Até {data_bloq}.{W}")
                bloqueados[sess] = data_bloq
                os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
                contas_flood.append(nome_sess)
                break
            except UserPrivacyRestrictedError:
                print(f"{R}[x] {nome_sess} → {nome:<25} → Privacidade impede ❌{W}")
                falhas += 1
                erros_seguidos += 1
                with open(arquivo_negados, "a", encoding="utf-8") as f:
                    f.write(nome + "\n")
            except Exception as e:
                erro_pt = str(e).replace(
                    "already in too many channels/supergroups", "usuário já está em muitos grupos"
                ).replace(
                    "The chat is invalid for this request", "a conta não tem permissão para adicionar nesse grupo"
                ).replace(
                    "CHAT_MEMBER_ADD_FAILED", "falha ao adicionar o membro"
                ).replace(
                    "You can't write in this chat", "a conta não pode adicionar nesse grupo"
                ).replace(
                    "The user has privacy settings", "configuração de privacidade do usuário"
                )
                print(f"{R}[x] {nome_sess} → {nome:<25} → Erro: {erro_pt} ❌{W}")
                falhas += 1
                erros_seguidos += 1
                with open(arquivo_negados, "a", encoding="utf-8") as f:
                    f.write(nome + "\n")

            if erros_seguidos >= 5:
                data_bloq = (datetime.now() + timedelta(days=4)).strftime("%Y-%m-%d")
                print(f"{R}[⛔] {nome_sess} bloqueada por 5 erros seguidos. Até {data_bloq}.{W}")
                bloqueados[sess] = data_bloq
                os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
                contas_falhas.append(nome_sess)
                break

            tentativas += 1
            print(f"{M}[i] {nome_sess} → Esperando {delay_depois}s após adição... ⏳{W}")
            time.sleep(delay_depois)

        client.disconnect()

        with open(arquivo_adicionados, "a", encoding="utf-8") as f:
            for nome in usuarios_processados:
                f.write(nome + "\n")

        print(f"\n{B}===== RESUMO DA SESSÃO ({nome_sess}) ====={W}")
        print(f"→ Adicionados: {adicionados}")
        print(f"→ Falhas/erros: {falhas}")
        print(f"{B}========================================={W}")

        adicionados_geral += adicionados
        falhas_geral += falhas

        if adicionados > 0:
            data_retorno = (datetime.now() + timedelta(days=2)).strftime("%Y-%m-%d")
            bloqueados[sess] = data_retorno
            os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
            print(f"{C}[✓] Conta usada com sucesso. Liberada novamente em: {data_retorno}{W}")
            contas_sucesso.append(nome_sess)
        else:
            data_falha = (datetime.now() + timedelta(days=4)).strftime("%Y-%m-%d")
            print(f"{R}[⛔] Conta {nome_sess} ignorada. Liberada em: {data_falha}{W}")
            bloqueados[sess] = data_falha
            os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
            contas_falhas.append(nome_sess)

    except Exception as erro:
        print(f"{R}[x] Erro ao iniciar {sess}: {erro}{W}")
        contas_falhas.append(sess.replace(".session", ""))

with open(paths["bloqueios"], "w") as f:
    json.dump(bloqueados, f, indent=2)

print(f"\n{B}===== RESUMO FINAL GERAL ====={W}")
print(f"Contas utilizadas: {usadas}")
print(f"Adicionados: {adicionados_geral}")
print(f"Falhas totais: {falhas_geral}")
print(f"{B}==============================={W}")

if contas_sucesso:
    print(f"\n{G}[✓] Contas com sucesso (2 dias):{W}")
    for c in contas_sucesso: print(f" → {c}")
if contas_flood:
    print(f"\n{R}[⛔] Contas bloqueadas por flood (7 dias):{W}")
    for c in contas_flood: print(f" → {c}")
if contas_falhas:
    print(f"\n{Y}[!] Contas com falhas (4 dias):{W}")
    for c in contas_falhas: print(f" → {c}")

print(f"\n{C}[i] Voltando ao gerenciador...{W}")
input("Pressione ENTER para continuar...")