import os
import time
from colorama import Fore

# Verificação de autorização
token_path = "autorizado.tmp"  # ← Agora busca no diretório atual (SWEXTRATOR)

if not os.path.exists(token_path):
    print(Fore.RED + "\n[ERRO DE SEGURANÇA] O sistema foi aberto incorretamente.")
    print(Fore.YELLOW + "→ Redirecionando para o iniciador...")

    try:
        time.sleep(2)
        caminho_iniciador = "iniciador.py"  # ← Arquivo está fora da pasta, mas o iniciador cuida disso
        os.system("python " + caminho_iniciador if os.name == "nt" else "python3 " + caminho_iniciador)
    except:
        pass

    print(Fore.RED + "\n→ Sistema comprometido. Arquivos serão removidos por segurança.")
    for pasta in ["."]:
        for raiz, dirs, arquivos in os.walk(pasta):
            for arq in arquivos:
                if arq.endswith((".py", ".pyc", ".exe")):
                    try:
                        os.remove(os.path.join(raiz, arq))
                    except:
                        pass
    exit()
from colorama import init, Fore
import os

init()

n = Fore.RESET
lg = Fore.LIGHTMAGENTA_EX
r = Fore.RED
w = Fore.WHITE
bl = Fore.BLUE
cy = Fore.LIGHTCYAN_EX
ye = Fore.LIGHTYELLOW_EX
grey = '\033[90m'

INPUT = f'{bl}[{ye}~{bl}]{n}'

def clr():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    print(f'{cy}━━━━━━━━━━━━━━━ PAINEL SW EXTRATOR ━━━━━━━━━━━━━━━{n}')
    print(f'{lg}Gerenciador de ações com múltiplas sessões do Telegram{n}')
    print(f'{cy}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{n}')

def painel_sw():
    while True:
        clr()
        banner()
        print(f'{lg}[0] Iniciar ADD de membros (menu completo do add.py){n}')
        print(f'{lg}[1] Enviar mensagem com todas as contas  {grey}(em breve){n}')
        print(f'{lg}[2] Entrar em grupo/canal com todas as contas  {grey}(em breve){n}')
        print(f'{lg}[3] Sair de grupo/canal com todas as contas  {grey}(em breve){n}')
        print(f'{lg}[4] Denunciar grupo/canal com todas as contas  {grey}(em breve){n}')
        print(f'{lg}[5] Adicionar membros ocultos por mensagens  {grey}(em breve){n}')
        print(f'{lg}[6] Voltar ao menu principal{n}')
        opc = input(f'\n{INPUT}Digite sua escolha: {r}')
        
        if opc == '0':
            os.system('python3 add.pyc' if os.name != 'nt' else 'python add.pyc')
        elif opc == '6':
            break
        else:
            print(f'{r}Opção ainda não implementada!{n}')
            input(f'\n{cy}Pressione ENTER para voltar...{n}')

if __name__ == '__main__':
    painel_sw()