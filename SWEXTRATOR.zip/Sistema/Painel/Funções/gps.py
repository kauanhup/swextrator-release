import os, time, json
from datetime import datetime
from colorama import Fore
from telethon.sync import TelegramClient
from telethon.tl.functions.channels import LeaveChannelRequest, JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest

# Cores
R = '\033[91m'; G = '\033[92m'; Y = '\033[93m'; B = '\033[94m'
M = '\033[95m'; C = '\033[96m'; W = '\033[0m'

# Caminhos
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
SESSIONS = {
    "ativas": os.path.join(BASE, "sessions", "ativas"),
    "bloqueadas": os.path.join(BASE, "sessions", "bloqueadas"),
    "banidas": os.path.join(BASE, "sessions", "banidas"),
    "bloqueios": os.path.join(BASE, "bloqueios.json")
}

api_id = 26957724
api_hash = "b02f0e7ec1ffd93427769d74979ab635"

# Garantir arquivos e pastas
for nome, caminho in SESSIONS.items():
    if nome == "bloqueios":
        if not os.path.exists(caminho):
            with open(caminho, "w") as f: json.dump({}, f)
    else:
        os.makedirs(caminho, exist_ok=True)

# Reativar sessões desbloqueadas
with open(SESSIONS["bloqueios"], "r") as f:
    bloqueados = json.load(f)

for sess in os.listdir(SESSIONS["bloqueadas"]):
    if sess.endswith(".session"):
        data = bloqueados.get(sess)
        if data and datetime.now() >= datetime.strptime(data, "%Y-%m-%d"):
            os.rename(os.path.join(SESSIONS["bloqueadas"], sess), os.path.join(SESSIONS["ativas"], sess))
            del bloqueados[sess]

with open(SESSIONS["bloqueios"], "w") as f:
    json.dump(bloqueados, f, indent=2)

# Contar sessões
ativas = [f for f in os.listdir(SESSIONS["ativas"]) if f.endswith(".session")]
bloq = [f for f in os.listdir(SESSIONS["bloqueadas"]) if f.endswith(".session")]
ban = [f for f in os.listdir(SESSIONS["banidas"]) if f.endswith(".session")]

print(f"\n{B}=========================================={W}")
print(f"{G}[✓] Sessões ativas: {len(ativas)}{W}")
print(f"{Y}[~] Sessões bloqueadas: {len(bloq)}{W}")
print(f"{R}[✘] Sessões banidas: {len(ban)}{W}")
print(f"{B}=========================================={W}")
print(f"\n{C}[i] Contas disponíveis para uso: {len(ativas)}{W}")

try:
    qtd = int(input(f"{M}[~] Quantas contas deseja usar? (máx {len(ativas)}): {W}"))
    sessoes_livres = ativas[:qtd]
except:
    sessoes_livres = ativas

grupo = input(f"\n{M}[~] Link do grupo (público ou privado): {W}").strip()

print(f"\n{B}→ Iniciando saída das contas...{W}")
sairam, falharam = [], []

for sess in sessoes_livres:
    nome = sess.replace(".session", "")
    caminho = os.path.join(SESSIONS["ativas"], sess)
    try:
        client = TelegramClient(caminho.replace(".session", ""), api_id, api_hash)
        client.start()
        if "joinchat" in grupo or "+" in grupo:
            hash = grupo.split("/")[-1].replace("+", "")
            client(ImportChatInviteRequest(hash))
        else:
            client(JoinChannelRequest(grupo))
        entidade = client.get_entity(grupo)
        client(LeaveChannelRequest(entidade))
        me = client.get_me()
        print(f"{G}[✓] {me.first_name or nome} saiu do grupo com sucesso.{W}")
        sairam.append(nome)
        client.disconnect()
    except Exception as e:
        print(f"{R}[x] {nome} falhou ao sair: {str(e)}{W}")
        falharam.append(nome)

# Resumo
print(f"\n{B}========= RESUMO ========={W}")
print(f"{G}Sairam: {len(sairam)}{W}")
print(f"{R}Falharam: {len(falharam)}{W}")
input(f"\n{C}Pressione ENTER para voltar...{W}")