import os, time, json
from datetime import datetime, timedelta
from colorama import Fore
from telethon.sync import TelegramClient
from telethon.errors import PeerFloodError, UserPrivacyRestrictedError
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.types import UserStatusOnline, UserStatusRecently

R = '\033[91m'; G = '\033[92m'; Y = '\033[93m'; B = '\033[94m'
M = '\033[95m'; C = '\033[96m'; W = '\033[0m'

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
ENVIAR_DIR = os.path.join(BASE, "EnviarMensagens")
CACHE_DIR = os.path.join(ENVIAR_DIR, "cache")
VIDEOS_DIR = os.path.join(ENVIAR_DIR, "videos")
SESSIONS_DIR = os.path.join(BASE, "sessions")

api_id = 26957724
api_hash = "b02f0e7ec1ffd93427769d74979ab635"

paths = {
    "ativas": os.path.join(SESSIONS_DIR, "ativas"),
    "bloqueadas": os.path.join(SESSIONS_DIR, "bloqueadas"),
    "banidas": os.path.join(SESSIONS_DIR, "banidas"),
    "bloqueios": os.path.join(BASE, "bloqueios.json"),
    "negados": os.path.join(BASE, "negados.txt"),
    "pulados": os.path.join(BASE, "pulados.txt"),
    "enviados": os.path.join(CACHE_DIR, "mensagens_enviadas.txt"),
}

for p in [paths["ativas"], paths["bloqueadas"], paths["banidas"], CACHE_DIR, VIDEOS_DIR]:
    os.makedirs(p, exist_ok=True)

for log in ["bloqueios", "negados", "pulados", "enviados"]:
    if not os.path.exists(paths[log]):
        open(paths[log], "a", encoding="utf-8").close()
if not os.path.exists(paths["bloqueios"]):
    with open(paths["bloqueios"], "w") as f: json.dump({}, f)

with open(paths["bloqueios"], "r") as f: bloqueados = json.load(f)

for sess in os.listdir(paths["bloqueadas"]):
    if sess.endswith(".session"):
        data = bloqueados.get(sess)
        if data and datetime.now() >= datetime.strptime(data, "%Y-%m-%d"):
            os.rename(os.path.join(paths["bloqueadas"], sess), os.path.join(paths["ativas"], sess))
            del bloqueados[sess]

with open(paths["bloqueios"], "w") as f:
    json.dump(bloqueados, f, indent=2)

ativas = [f for f in os.listdir(paths["ativas"]) if f.endswith(".session")]
bloq = [f for f in os.listdir(paths["bloqueadas"]) if f.endswith(".session")]
ban = [f for f in os.listdir(paths["banidas"]) if f.endswith(".session")]

print(f"\n{B}=========================================={W}")
print(f"{G}[✓] Sessões ativas: {len(ativas)}{W}")
print(f"{Y}[~] Sessões bloqueadas: {len(bloq)}{W}")
print(f"{R}[✘] Sessões banidas: {len(ban)}{W}")
print(f"{B}=========================================={W}")
print(f"\n{C}[i] Contas disponíveis para uso: {len(ativas)}{W}")
try:
    qtd = int(input(f"{M}[~] Quantas contas deseja usar? (máx {len(ativas)}): {W}"))
    sessoes_livres = ativas[:qtd]
except:
    sessoes_livres = ativas

grupo_origem = input(f"\n{M}[~] Grupo de origem (link): {W}").strip()
dias = int(input(f"{M}[~] Quantos dias deseja buscar mensagens? (ex: 7): {W}"))
usar_filtro = input(f"{M}[~] Ativar filtro de usuários reais? [s/n]: {W}").lower() == "s"
mensagem = input(f"{M}[~] Digite a mensagem a ser enviada: {W}")
usar_video = input(f"{M}[~] Deseja enviar um vídeo? [s/n]: {W}").lower() == "s"
video_path = ""

if usar_video:
    videos_disponiveis = [v for v in os.listdir(VIDEOS_DIR) if v.endswith(".mp4")]
    if not videos_disponiveis:
        print(f"{R}[x] Nenhum vídeo encontrado na pasta.{W}")
        usar_video = False
    else:
        for i, nome in enumerate(videos_disponiveis, 1):
            print(f"{Y}[{i}] {nome}{W}")
        escolha = int(input(f"{M}[~] Escolha o número do vídeo: {W}"))
        video_path = os.path.join(VIDEOS_DIR, videos_disponiveis[escolha - 1])
        delay = int(input(f"{M}[~] Tempo de espera entre mensagens (ex: 30): {W}"))

with open(paths["negados"], "r", encoding="utf-8") as f: negados = set(f.read().splitlines())
with open(paths["pulados"], "r", encoding="utf-8") as f: pulados = set(f.read().splitlines())
with open(paths["enviados"], "r", encoding="utf-8") as f: enviados = set(f.read().splitlines())
ja_usados = negados | pulados | enviados

limite_data = datetime.now() - timedelta(days=dias)
for sess in sessoes_livres:
    try:
        nome_sess = sess.replace(".session", "")
        caminho_sess = os.path.join(paths["ativas"], sess)
        client = TelegramClient(caminho_sess, api_id, api_hash)
        client.start()
        me = client.get_me()
        nome_exibicao = me.first_name or me.username or nome_sess
        print(f"\n{C}→ Iniciando sessão: {nome_exibicao}{W}")

        if "joinchat" in grupo_origem:
            hash_convite = grupo_origem.split("/")[-1].replace("+", "")
            client(ImportChatInviteRequest(hash_convite))
        else:
            client(JoinChannelRequest(grupo_origem))

        entidade = client.get_entity(grupo_origem)
        participantes = []
        print(f"{C}→ Extraindo mensagens do grupo...{W}")
        for msg in client.iter_messages(entidade, limit=1000):
            if msg.date < limite_data:
                break
            sender = msg.sender
            if not sender or not sender.username:
                continue
            username = f"@{sender.username}"
            if username in ja_usados or any(username == f"@{u.username}" for u in participantes if u.username):
                continue
            if usar_filtro and (sender.bot or sender.deleted or not isinstance(sender.status, (UserStatusOnline, UserStatusRecently))):
                with open(paths["pulados"], "a", encoding="utf-8") as f:
                    f.write(username + "\n")
                pulados.add(username)
                continue
            participantes.append(sender)
            if len(participantes) >= 25:
                break

        print(f"{C}→ Cache atualizado: {len(participantes)} membros prontos para envio.{W}")
        enviados_sessao = 0
        for i, user in enumerate(participantes, 1):
            if enviados_sessao >= 25: break
            nome = "@" + user.username
            print(f"{M}[{i}/25] {nome_exibicao} → Enviando mensagem...{W}")
            try:
                time.sleep(10)
                try:
                    if usar_video and video_path:
                        client.send_file(user, video_path, caption=mensagem)
                    else:
                        client.send_message(user, mensagem)
                    print(f"{G}[✓] Mensagem enviada para {nome}{W}")
                    enviados_sessao += 1
                    enviados.add(nome)
                    with open(paths["enviados"], "a", encoding="utf-8") as f:
                        f.write(nome + "\n")
                except Exception as e:
                    print(f"{R}[x] Erro ao enviar para {nome}: {e}{W}")
                    negados.add(nome)
                    with open(paths["negados"], "a", encoding="utf-8") as f:
                        f.write(nome + "\n")
                    continue
                print(f"{C}→ Aguardando {delay}s...{W}")
                time.sleep(delay)
            except UserPrivacyRestrictedError:
                print(f"{Y}[!] Privacidade impede envio para {nome}{W}")
                negados.add(nome)
                with open(paths["negados"], "a", encoding="utf-8") as f:
                    f.write(nome + "\n")
            except PeerFloodError:
                data_bloq = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
                print(f"{R}→ Flood detectado. Bloqueando {nome_exibicao} até {data_bloq}.{W}")
                bloqueados[sess] = data_bloq
                os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
                break
            except Exception as e:
                print(f"{R}[x] Erro ao enviar para {nome}: {str(e)}{W}")

        client.disconnect()
        if enviados_sessao == 0:
            data_bloq = (datetime.now() + timedelta(days=4)).strftime("%Y-%m-%d")
        else:
            data_bloq = (datetime.now() + timedelta(days=2)).strftime("%Y-%m-%d")
        bloqueados[sess] = data_bloq
        os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
        print(f"{Y}→ Sessão {nome_exibicao} bloqueada até {data_bloq}{W}")

    except Exception as e:
        print(f"{R}[x] Erro geral em {sess}: {e}{W}")

with open(paths["bloqueios"], "w") as f:
    json.dump(bloqueados, f, indent=2)

input(f"\n{C}Processo finalizado. Pressione ENTER para voltar...{W}")