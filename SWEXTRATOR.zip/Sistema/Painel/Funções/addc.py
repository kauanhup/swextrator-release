import os, time, json
from datetime import datetime, timedelta
from colorama import Fore
from telethon.sync import TelegramClient
from telethon.errors import PeerFloodError, UserPrivacyRestrictedError, PhoneNumberInvalidError
from telethon.tl.functions.channels import InviteToChannelRequest, JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest, GetHistoryRequest
from telethon.tl.types import Message, User, UserStatusOnline, UserStatusRecently

R = '\033[91m'; G = '\033[92m'; Y = '\033[93m'; B = '\033[94m'
M = '\033[95m'; C = '\033[96m'; W = '\033[0m'

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
api_id = 26957724
api_hash = "b02f0e7ec1ffd93427769d74979ab635"

paths = {
    "ativas": os.path.join(BASE, "sessions", "ativas"),
    "bloqueadas": os.path.join(BASE, "sessions", "bloqueadas"),
    "banidas": os.path.join(BASE, "sessions", "banidas"),
    "adicionados": os.path.join(BASE, "adicionados"),
    "negados": os.path.join(BASE, "negados.txt"),
    "pulados": os.path.join(BASE, "pulados.txt"),
    "bloqueios": os.path.join(BASE, "bloqueios.json"),
    "cache": os.path.join(BASE, "cache")
}

for k, p in paths.items():
    if "bloqueios" in k and not os.path.exists(p):
        with open(p, "w") as f:
            json.dump({}, f)
    elif k in ["pulados", "negados"] and not os.path.exists(p):
        open(p, "a").close()
    elif not os.path.exists(p):
        os.makedirs(p, exist_ok=True)

with open(paths["bloqueios"], "r") as f:
    bloqueados = json.load(f)

for sess in os.listdir(paths["bloqueadas"]):
    if sess.endswith(".session"):
        data = bloqueados.get(sess)
        if data and datetime.now() >= datetime.strptime(data, "%Y-%m-%d"):
            os.rename(os.path.join(paths["bloqueadas"], sess), os.path.join(paths["ativas"], sess))
            del bloqueados[sess]

with open(paths["bloqueios"], "w") as f:
    json.dump(bloqueados, f, indent=2)

ativas = [f for f in os.listdir(paths["ativas"]) if f.endswith(".session")]
bloq = [f for f in os.listdir(paths["bloqueadas"]) if f.endswith(".session")]
ban = [f for f in os.listdir(paths["banidas"]) if f.endswith(".session")]

print(f"\n{B}=========================================={W}")
print(f"{G}[✓] Sessões ativas: {len(ativas)}{W}")
print(f"{Y}[~] Sessões bloqueadas: {len(bloq)}{W}")
print(f"{R}[✘] Sessões banidas: {len(ban)}{W}")
print(f"{B}=========================================={W}")
print(f"\n{C}[i] Contas disponíveis para uso: {len(ativas)}{W}")
try:
    qtd = int(input(f"{M}[~] Quantas contas deseja usar? (máx {len(ativas)}): {W}"))
    sessoes_livres = ativas[:qtd]
except:
    print(f"{Y}Usando todas as contas disponíveis.{W}")
    sessoes_livres = ativas

grupo_origem = input(f"\n{M}[~] Grupo de origem (link): {W}").strip()
dias = int(input(f"{M}[~] Quantos dias deseja buscar mensagens? (ex: 7): {W}"))
grupo_destino = input(f"{M}[~] Grupo de destino (link): {W}").strip()
usar_filtro = input(f"{M}[~] Ativar filtro de usuários reais? [s/n]: {W}").lower() == "s"
delay_antes = 10
delay_depois = int(input(f"{M}[~] Tempo de espera após adicionar (ex: 25): {W}"))
grupo_nome = grupo_destino.replace("https://t.me/", "").replace("/", "_")
cache_membros = os.path.join(paths["cache"], f"membros_{grupo_nome}.json")
arquivo_adicionados = os.path.join(paths["adicionados"], f"{grupo_nome}.txt")
arquivo_negados = paths["negados"]
arquivo_pulados = paths["pulados"]

def atualizar_cache():
    primeira_sessao = sessoes_livres[0]
    caminho_sess = os.path.join(paths["ativas"], primeira_sessao)
    client_temp = TelegramClient(caminho_sess.replace(".session", ""), api_id, api_hash)
    client_temp.start()
    entidade_origem = client_temp.get_entity(grupo_origem)
    limite_data = datetime.now() - timedelta(days=dias)

    adicionados_memoria = open(arquivo_adicionados, "r", encoding="utf-8").read().splitlines() if os.path.exists(arquivo_adicionados) else []
    negados_memoria = open(arquivo_negados, "r", encoding="utf-8").read().splitlines()
    pulados_memoria = open(arquivo_pulados, "r", encoding="utf-8").read().splitlines()
    ja_usados = set([x.replace("@", "") for x in adicionados_memoria + negados_memoria + pulados_memoria])

    membros_validos = []
    offset_id = 0

    while True:
        historico = client_temp(GetHistoryRequest(peer=entidade_origem, offset_id=offset_id, offset_date=None, add_offset=0, limit=100, max_id=0, min_id=0, hash=0))
        if not historico.messages:
            break
        for msg in historico.messages:
            if isinstance(msg, Message) and msg.sender_id:
                try:
                    remetente = client_temp.get_entity(msg.sender_id)
                    if isinstance(remetente, User) and remetente.username and remetente.username not in ja_usados:
                        if not usar_filtro or (not remetente.bot and not remetente.deleted and isinstance(remetente.status, (UserStatusOnline, UserStatusRecently))):
                            membros_validos.append({"username": remetente.username})
                            if len(membros_validos) >= len(sessoes_livres) * 50:
                                break
                except:
                    continue
        offset_id = historico.messages[-1].id
        if historico.messages[-1].date < limite_data or len(membros_validos) >= len(sessoes_livres) * 50:
            break

    client_temp.disconnect()
    with open(cache_membros, "w", encoding="utf-8") as f:
        json.dump(membros_validos, f, ensure_ascii=False, indent=2)
        if not os.path.exists(cache_membros): atualizar_cache()

with open(cache_membros, "r", encoding="utf-8") as f:
    dados_membros = json.load(f)

print(f"{C}→ Cache atualizado: {len(dados_membros)} membros extraídos por mensagens.{W}")

participantes_usernames = [m["username"] for m in dados_membros]
dividido = [participantes_usernames[i*50:(i+1)*50] for i in range(len(sessoes_livres))]

pulados_memoria = open(arquivo_pulados, "r", encoding="utf-8").read().splitlines()
adicionados_memoria = open(arquivo_adicionados, "r", encoding="utf-8").read().splitlines() if os.path.exists(arquivo_adicionados) else []
negados_memoria = open(arquivo_negados, "r", encoding="utf-8").read().splitlines()

usadas = 0
adicionados_geral = 0
falhas_geral = 0
contas_sucesso = []
contas_flood = []
contas_falhas = []
for i, sess in enumerate(sessoes_livres):
    membros_sessao = dividido[i] if i < len(dividido) else []
    try:
        tentativas = 0
        adicionados = 0
        falhas = 0
        erros_seguidos = 0
        nome_sess = sess.replace(".session", "")
        caminho_sess = os.path.join(paths["ativas"], sess)

        client = TelegramClient(caminho_sess.replace(".session", ""), api_id, api_hash)
        client.start()
        me = client.get_me()
        nome_sess = me.first_name or me.username or sess.replace(".session", "")
        print(f"\n{C}→ Iniciando sessão: {nome_sess}{W}")
        usadas += 1

        if "joinchat" in grupo_destino:
            hash_convite = grupo_destino.split("/")[-1].replace("+", "")
            client(ImportChatInviteRequest(hash_convite))
        else:
            client(JoinChannelRequest(grupo_destino))
        entidade_destino = client.get_entity(grupo_destino)
        print(f"{G}→ Entrou no grupo de destino com sucesso.{W}")

        for username in membros_sessao:
            if tentativas >= 50:
                break

            nome = "@" + username
            if nome in adicionados_memoria or nome in negados_memoria or nome in pulados_memoria:
                continue

            try:
                user = client.get_entity(username)
                nome_exibicao = user.first_name if hasattr(user, 'first_name') and user.first_name else nome

                if usar_filtro and (user.bot or user.deleted or not isinstance(user.status, (UserStatusOnline, UserStatusRecently))):
                    with open(arquivo_pulados, "a", encoding="utf-8") as f:
                        f.write(nome + "\n")
                    continue

                print(f"{M}→ Adicionando... [{tentativas + 1}/{len(membros_sessao)}]{W}")
                time.sleep(delay_antes)

                client(InviteToChannelRequest(entidade_destino, [user]))
                print(f"{G}[✓] {nome_sess} adicionou {nome_exibicao}{W}")
                adicionados += 1
                erros_seguidos = 0
                with open(arquivo_adicionados, "a", encoding="utf-8") as f:
                    f.write(nome + "\n")

            except PeerFloodError:
                data_bloq = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
                print(f"{R}→ Flood detectado. Bloqueando até {data_bloq}.{W}")
                bloqueados[sess] = data_bloq
                os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
                contas_flood.append(nome_sess)
                break

            except UserPrivacyRestrictedError:
                print(f"{R}[x] {nome_sess} não conseguiu adicionar {nome_exibicao}: privacidade impede{W}")
                falhas += 1
                erros_seguidos += 1
                with open(arquivo_negados, "a", encoding="utf-8") as f:
                    f.write(nome + "\n")

            except PhoneNumberInvalidError:
                print(f"{R}[x] {nome_sess} foi detectado como banido e movido para banidas.{W}")
                os.rename(caminho_sess, os.path.join(paths["banidas"], sess))
                contas_falhas.append(nome_sess)
                break

            except Exception as e:
                print(f"{R}[x] {nome} → Erro inesperado: {str(e)}{W}")
                falhas += 1
                erros_seguidos += 1
                with open(arquivo_negados, "a", encoding="utf-8") as f:
                    f.write(nome + "\n")

            dados_membros = [m for m in dados_membros if m["username"] != username]
            with open(cache_membros, "w", encoding="utf-8") as f:
                json.dump(dados_membros, f, ensure_ascii=False, indent=2)

            if erros_seguidos >= 5:
                data_bloq = (datetime.now() + timedelta(days=4)).strftime("%Y-%m-%d")
                print(f"{R}→ 5 erros seguidos. Bloqueando até {data_bloq}.{W}")
                bloqueados[sess] = data_bloq
                os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
                contas_falhas.append(nome_sess)
                break

            tentativas += 1
            print(f"{M}→ Esperando {delay_depois}s após adição...{W}")
            time.sleep(delay_depois)

        client.disconnect()

        print(f"\n{B}===== RESUMO ({nome_sess}) ====={W}")
        print(f"Adicionados: {adicionados}")
        print(f"Falhas: {falhas}")
        adicionados_geral += adicionados
        falhas_geral += falhas

        if tentativas > 0 and adicionados == 0:
            data_fail = (datetime.now() + timedelta(days=4)).strftime("%Y-%m-%d")
            bloqueados[sess] = data_fail
            os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
            contas_falhas.append(nome_sess)
        elif adicionados > 0:
            data_ok = (datetime.now() + timedelta(days=2)).strftime("%Y-%m-%d")
            bloqueados[sess] = data_ok
            os.rename(caminho_sess, os.path.join(paths["bloqueadas"], sess))
            contas_sucesso.append(nome_sess)

    except Exception as e:
        print(f"{R}[x] Erro geral em {sess}: {e}{W}")
        contas_falhas.append(sess.replace(".session", ""))

with open(paths["bloqueios"], "w") as f:
    json.dump(bloqueados, f, indent=2)

print(f"\n{B}===== RESUMO FINAL ====={W}")
print(f"Contas usadas: {usadas}")
print(f"Adicionados: {adicionados_geral}")
print(f"Falhas: {falhas_geral}")

if contas_sucesso:
    print(f"\n{G}[✓] Contas com sucesso:{W}")
    for c in contas_sucesso:
        print(" →", c)

if contas_flood:
    print(f"\n{R}Flood detectado (7 dias):{W}")
    for c in contas_flood:
        print(" →", c)

if contas_falhas:
    print(f"\n{Y}Falhas (4 dias):{W}")
    for c in contas_falhas:
        print(" →", c)

input(f"\n{C}Pressione ENTER para voltar...{W}")