import os
import time
from colorama import Fore, init

init()

# Cores
n = Fore.RESET
lg = Fore.LIGHTMAGENTA_EX
r = Fore.RED
w = Fore.WHITE
bl = Fore.BLUE
cy = Fore.LIGHTCYAN_EX
ye = Fore.LIGHTYELLOW_EX
grey = '\033[90m'

INPUT = f'{bl}[{ye}~{bl}]{n}'

# Base: pasta onde está o swpainel.py
BASE = os.path.dirname(os.path.abspath(__file__))
FUNCOES = os.path.join(BASE, "funções")

def clr():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    print(f'{cy}━━━━━━━━━━━━━━━ PAINEL SW EXTRATOR ━━━━━━━━━━━━━━━{n}')
    print(f'{lg}Gerenciador de ações com múltiplas sessões do Telegram{n}')
    print(f'{cy}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{n}')

def painel_sw():
    while True:
        clr()
        banner()
        print(f'{lg}[0] Adicionar membros normalmente{n}')
        print(f'{lg}[1] Enviar mensagens privadas (DM){n}')
        print(f'{lg}[2] Enviar mensagens em grupos/canais{n}')
        print(f'{lg}[3] Entrar em grupo/canal com todas as contas{n}')
        print(f'{lg}[4] Denunciar grupo/canal com todas as contas  {ye}(em atualização){n}')
        print(f'{lg}[5] Adicionar membros ocultos por mensagens{n}')
        print(f'{lg}[6] Sair de grupo/canal com todas as contas{n}')
        print(f'{lg}[7] Denunciar membros de um grupo  {grey}(em breve){n}')
        print(f'{lg}[8] Voltar ao menu principal{n}')
        opc = input(f'\n{INPUT}Digite sua escolha: {r}')
        
        if opc == '0':
            path = os.path.join(FUNCOES, "add.py")
        elif opc == '1':
            path = os.path.join(FUNCOES, "msg.py")
        elif opc == '2':
            path = os.path.join(FUNCOES, "msgc.py")
        elif opc == '3':
            path = os.path.join(FUNCOES, "gpe.py")
        elif opc == '4':
            print(f'\n{ye}→ Essa função está sendo atualizada. Em breve estará disponível!{n}')
            input(f'{cy}Pressione ENTER para voltar...{n}')
            continue
        elif opc == '5':
            path = os.path.join(FUNCOES, "addc.py")
        elif opc == '6':
            path = os.path.join(FUNCOES, "gps.py")
        elif opc == '7':
            print(f'\n{ye}→ Função de denunciar membros em breve!{n}')
            input(f'{cy}Pressione ENTER para voltar...{n}')
            continue
        elif opc == '8':
            break
        else:
            print(f'{r}Opção inválida!{n}')
            input(f'\n{cy}Pressione ENTER para voltar...{n}')
            continue

        print(f'\n{ye}→ Executando:\n')
        os.system(f'python "{path}"' if os.name == 'nt' else f'bash -c \'python3 "{path}"; read -p "Pressione ENTER para voltar..."\'')        

if __name__ == '__main__':
    painel_sw()