import os
import time
import shutil
import json
from telethon.sync import TelegramClient
from telethon.errors.rpcerrorlist import PhoneNumberBannedError
from colorama import init, Fore
from time import sleep
from datetime import datetime

# Inicialização do Colorama
init()

# Diretório base do sistema (SWStrator/)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# Cores
n = Fore.RESET
lg = Fore.LIGHTMAGENTA_EX
r = Fore.RED
w = Fore.WHITE
bl = Fore.BLUE
cy = Fore.LIGHTCYAN_EX
ye = Fore.LIGHTYELLOW_EX
colors = [lg, r, bl, cy, ye]

API_ID = 26957724
API_HASH = 'b02f0e7ec1ffd93427769d74979ab635'

# Verificação de autorização
token_path = os.path.join(BASE_DIR, "autorizado.tmp")

if not os.path.exists(token_path):
    print(Fore.RED + "\n[ERRO DE SEGURANÇA] O sistema foi aberto incorretamente.")
    print(Fore.YELLOW + "→ Redirecionando para o iniciador...")

    try:
        time.sleep(2)
        caminho_iniciador = os.path.abspath(os.path.join(BASE_DIR, "..", "iniciar.py"))
        os.system("python " + caminho_iniciador if os.name == "nt" else "python3 " + caminho_iniciador)
    except:
        pass

    print(Fore.RED + "\n→ Sistema comprometido. Arquivos serão removidos por segurança.")
    for pasta in [BASE_DIR]:
        for raiz, dirs, arquivos in os.walk(pasta):
            for arq in arquivos:
                if arq.endswith((".py", ".pyc", ".exe")):
                    try:
                        os.remove(os.path.join(raiz, arq))
                    except:
                        pass
    exit()

paths = {
    "ativas": os.path.join(BASE_DIR, "sessions", "ativas"),
    "banidas": os.path.join(BASE_DIR, "sessions", "banidas"),
    "bloqueadas": os.path.join(BASE_DIR, "sessions", "bloqueadas")
}

def banner():
    from pyfiglet import Figlet
    f = Figlet(font="slant")
    print(Fore.GREEN + f.renderText("SW EXTRATOR").rstrip())
    print(Fore.CYAN + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(Fore.LIGHTGREEN_EX + "Versão: 4.0" + Fore.YELLOW + " | Gerenciador avançado de sessões do Telegram")
    print(Fore.CYAN + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" + Fore.RESET)

def clr():
    os.system('cls' if os.name == 'nt' else 'clear')

def criar_pastas():
    for path in paths.values():
        os.makedirs(path, exist_ok=True)

def add_new_accounts():
    quantidade = int(input(f'\n{bl}[{ye}~{bl}]{n}Quantas contas deseja adicionar? {r}'))
    for _ in range(quantidade):
        numero = input(f'{bl}[{ye}~{bl}]{n}Digite o número com DDI (ex: +55...): {r}').strip()
        nome_sessao = numero.replace("+", "").replace(" ", "")
        caminho = os.path.join(paths["ativas"], f"{nome_sessao}.session")
        cliente = TelegramClient(caminho.replace(".session", ""), API_ID, API_HASH)
        try:
            cliente.start(phone=numero)
            print(f'{lg}[+] Conta {nome_sessao} adicionada com sucesso!{n}')
        except PhoneNumberBannedError:
            print(f'{r}[-] Conta {nome_sessao} está banida!{n}')
            shutil.move(caminho, os.path.join(paths["banidas"], f"{nome_sessao}.session"))
        cliente.disconnect()
    input(f'\n{cy}Pressione ENTER para voltar ao menu...{n}')

def filter_banned_accounts():
    contas = os.listdir(paths["ativas"])
    if not contas:
        print(f'{r}[!] Nenhuma conta ativa para verificar!{n}')
        sleep(2)
        return
    for sess in contas:
        nome = sess.replace(".session", "")
        caminho = os.path.join(paths["ativas"], sess)
        cliente = TelegramClient(caminho.replace(".session", ""), API_ID, API_HASH)
        try:
            cliente.connect()
            if not cliente.is_user_authorized():
                print(f'{r}[-] {nome} está banida!{n}')
                shutil.move(caminho, os.path.join(paths["banidas"], sess))
            else:
                print(f'{lg}[+] {nome} está OK.{n}')
        except Exception as e:
            print(f'{r}[-] Erro ao verificar {nome}: {e}{n}')
        cliente.disconnect()
    input(f'\n{cy}Pressione ENTER para voltar ao menu...{n}')

def delete_specific_account():
    todas = []
    print(f'\n{lg}[i] Contas disponíveis:{n}')
    index = 0
    for status, pasta in paths.items():
        contas = os.listdir(pasta)
        for c in contas:
            nome = c.replace(".session", "")
            todas.append((nome, status, os.path.join(pasta, c)))
            print(f'{index} - {nome} ({status.upper()})')
            index += 1

    if not todas:
        print(f'{r}[!] Nenhuma conta encontrada para excluir!{n}')
        sleep(2)
        return

    try:
        idx = int(input(f'{bl}[{ye}~{bl}]{n}Digite o número da conta para excluir: {r}'))
        if 0 <= idx < len(todas):
            os.remove(todas[idx][2])
            print(f'{lg}[✓] Conta {todas[idx][0]} excluída com sucesso!{n}')
        else:
            print(f'{r}Opção inválida!{n}')
    except:
        print(f'{r}Entrada inválida!{n}')

    input(f'\n{cy}Pressione ENTER para voltar ao menu...{n}')

def update_script():
    print(f'\n{lg}[✓] Verificando versão... Já está atualizado!{n}')
    input(f'\n{cy}Pressione ENTER para voltar ao menu...{n}')

def display_all_accounts():
    bloqueios_path = os.path.join(BASE_DIR, "bloqueios.json")
    bloqueios = {}
    if os.path.exists(bloqueios_path):
        with open(bloqueios_path, "r") as f:
            bloqueios = json.load(f)

    total = 0

    print(f"\n{bl}[ATIVAS]{n}")
    contas_ativas = os.listdir(paths["ativas"])
    print(f" → {len(contas_ativas)} conta(s)")
    for c in contas_ativas:
        print(f"   → {c.replace('.session', '')}")
    total += len(contas_ativas)

    print(f"\n{bl}[BLOQUEADAS]{n}")
    contas_bloqueadas = os.listdir(paths["bloqueadas"])
    print(f" → {len(contas_bloqueadas)} conta(s)")
    for c in contas_bloqueadas:
        nome = c.replace(".session", "")
        info = bloqueios.get(nome, {})
        data = info.get("data", "??/??")
        motivo = info.get("motivo", "desconhecido")
        print(f"   → {nome} (libera em: {data} - motivo: {motivo})")
    total += len(contas_bloqueadas)

    print(f"\n{bl}[BANIDAS]{n}")
    contas_banidas = os.listdir(paths["banidas"])
    print(f" → {len(contas_banidas)} conta(s)")
    for c in contas_banidas:
        print(f"   → {c.replace('.session', '')}")
    total += len(contas_banidas)

    print(f"\n{ye}Total geral: {total} conta(s){n}")
    input(f'\n{cy}Pressione ENTER para voltar ao menu...{n}')

def iniciar_add():
    clr()
    banner()
    print(f'{lg}[i] Abrindo painel SW EXTRATOR...{n}')
    try:
        painel_path = os.path.join(BASE_DIR, "sistema", "painel", "swpainel.py")
        exit_code = os.system(f'python "{painel_path}"' if os.name == 'nt' else f'python3 "{painel_path}"')
        if exit_code != 0:
            raise Exception("Erro ao executar o painel.")
    except Exception as e:
        print(f'{r}[x] Erro ao abrir o painel: {e}{n}')
    input(f'{cy}Pressione ENTER para voltar ao menu...{n}')

def contato_dev():
    print(f'\n{ye}Para suporte ou dúvidas, entre em contato com o desenvolvedor:{n}')
    print(f'{lg}Telegram: {w}@error404Dev{n}')
    print(f'{lg}WhatsApp: {w}(51) 9815-4951{n}')
    print(f'{lg}Grupo no Telegram: {w}https://t.me/scriptwaree{n}')
    input(f'\n{cy}Pressione ENTER para voltar ao menu...{n}')

if __name__ == '__main__':
    criar_pastas()
    while True:
        clr()
        banner()
        print(f'{lg}[1] Adicionar novas contas{n}')
        print(f'{lg}[2] Filtrar contas banidas{n}')
        print(f'{lg}[3] Excluir contas específicas{n}')
        print(f'{lg}[4] Atualizar seu Script{n}')
        print(f'{lg}[5] Exibir todas as contas{n}')
        print(f'{lg}[6] Iniciar SW EXTRATOR (Painel de Ações){n}')
        print(f'{lg}[7] Contato com o Desenvolvedor{n}')
        print(f'{lg}[8] Sair{n}')
        a = input(f'\n{bl}[{ye}~{bl}]{n}Digite sua escolha: {r}')
        if a == '1':
            add_new_accounts()
        elif a == '2':
            filter_banned_accounts()
        elif a == '3':
            delete_specific_account()
        elif a == '4':
            update_script()
        elif a == '5':
            display_all_accounts()
        elif a == '6':
            iniciar_add()
        elif a == '7':
            contato_dev()
        elif a == '8':
            break

# Remove o token ao finalizar
try:
    os.remove(token_path)
except:
    pass